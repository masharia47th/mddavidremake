var $=jQuery;$(function(){if($('.wp-block-uagb-table-of-contents').length){const toc_block=$('.wp-block-uagb-table-of-contents');const floating_toc_sidebar=get_floating_toc_sidebar();const toc_top=$('.wp-block-uagb-table-of-contents').position().top;$(floating_toc_sidebar).prependTo('body');const sidebar_content=$('div.uagb-toc__list-wrap > ol.uagb-toc__list').clone()
sidebar_content.find('li, ul').removeAttr('class');sidebar_content.find('li ul').siblings('a').addClass('sco-toc-title');$('.sco-toc-parent-ul').append(sidebar_content.html());$('.sco-toc-parent-ul li ul').hide();$(".sco-toc:not(:first-of-type)").css("display","none");$(document).on('click','.sco-toc-title',function(){$(".open").not(this).removeClass("open").next().slideUp(300);$(this).toggleClass("open").next().slideToggle(300)});$(".sco-toc-head").click(function(){$(".sco-toc-wrapper").toggleClass("sco-toc-wrapper-open")});$(document).on('click','.sco-toc-expand-widget',function(){$(".sco-toc-head").trigger('click')})
var cur=[];var scrollItems=[];setTimeout(function(){scrollItems=$('article').find('span.uag-toc__heading-anchor')},500)
$(window).on('scroll',function(){let doc=document.documentElement;let left=(window.pageXOffset||doc.scrollLeft)-(doc.clientLeft||0);let top=(window.pageYOffset||doc.scrollTop)-(doc.clientTop||0);if(top>50){$('.sco-toc-wrapper').show()}else{if($(window).width()>mobile_toc_breakpoint){$('.sco-toc-wrapper').hide()}}
var fromTop=$(this).scrollTop();cur=[];if(scrollItems.length){scrollItems.each(function(){if($(this).offset().top<$(window).scrollTop()+100){cur.push($(this).attr('id'))}})}
if(cur.length){let activeId=cur[cur.length-1];activeAnchor=$('.sco-toc-parent-ul').find('a[href="#'+activeId+'"]');$('.sco-toc-parent-ul li ul').hide();$('.toc-item-active').removeClass('toc-item-active');$('.sco-toc-parent-ul > li > a').removeClass('open');if(!activeAnchor.hasClass('sco-toc-title')){activeAnchor.closest('ul').show();activeAnchor.addClass('toc-item-active');activeAnchor.closest('ul').siblings('a').addClass('open')}else{activeAnchor.addClass('open');activeAnchor.siblings('ul').show()}}})
$('.sco-toc-body-wrap ul a').on('click',function(event){event.preventDefault();$('html,body').animate({scrollTop:$(this.hash).offset().top-30},50);console.log('Mobile breakpoint: ',mobile_toc_breakpoint,'current width: ',$(window).width())
if(!$(this).hasClass('sco-toc-title')&&$(window).width()<defaultTocOpen){$('.sco-toc-wrapper').removeClass('sco-toc-wrapper-open')}})}
function get_floating_toc_sidebar(){let sidebar='<div style="display:none" class="sco-toc-wrapper">'
if($(window).width()>defaultTocOpen){sidebar='<div style="display:none" class="sco-toc-wrapper sco-toc-wrapper-open">'}
sidebar+='<div class="sco-toc-head-outer toc-head-with-cta">';sidebar+='<div class="sco-toc-head"><div><svg width="20" height="20" style="margin-right:15px;" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" class="fill-current "><path d="M3.349 8h1.474V.954h-1.47L1.534 2.22v1.328L3.26 2.346h.088V8zM.912 13.093H2.28c0-.689.45-1.172 1.167-1.172.689 0 1.09.459 1.09 1.035 0 .488-.191.81-1.07 1.665L.996 17.01V18h5.082v-1.186H2.982v-.088l1.465-1.397c1.172-1.113 1.533-1.68 1.533-2.505 0-1.186-.957-2.05-2.45-2.05-1.544 0-2.618.947-2.618 2.319z"></path><rect x="8" y="2" width="12" height="2" rx="1"></rect><rect x="8" y="8" width="12" height="2" rx="1"></rect><rect x="8" y="14" width="12" height="2" rx="1"></rect></svg><span>Table of Contents</span></div><svg class="sco-toc-close" width="20" height="20" viewBox="0 0 20 20" fill="#04042D" xmlns="http://www.w3.org/2000/svg" class=""><path d="M10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 011.414-1.414L10 8.586z"></path></svg></div>'
if(sidebarCTAButton){sidebar+=`<div class="sco-toc-cta-head sco-cta-head-width-50"><a class="sco-toc-head-cta-button" href="${cta_url}" target="_blank">${mobile_cta_button_text}</a></div>`}
sidebar+='</div>';sidebar+='<div class="sco-toc-body-wrap"><div class="sco-toc-body-inner-head"><ul class="sco-toc-parent-ul"></ul></div></div>'
if(sidebarCTAButton){sidebar+=`
                <div class="vip-cta-box">
                    <div class="vip-cta-content">
                        <div class="vip-cta-text-block">
                            <span class="vip-cta-text">${cta_text_1}</span>
                            <span class="vip-cta-text">${cta_text_2}</span>
                        </div>
                        <a class="vip-cta-button" href="${cta_url}" target="_blank">
                        ${desktop_cta_button_text}
                        </a>
                    </div>
                </div>
            `}
sidebar+='</div>'
return sidebar}})